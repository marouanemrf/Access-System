from db import init_db
from sign_in import sign_in_bp
from routes import general_bp, employee_bp
from event import event_bp
from camera import cam_bp
from dashboard import daboard_bp
from statistic import static_bp
from init import *

def create_app():
	cors.init_app(app)
	bcrypt.init_app(app)
	db = init_db(app)

	app.register_blueprint(sign_in_bp)
	app.register_blueprint(general_bp)
	app.register_blueprint(employee_bp)
	app.register_blueprint(cam_bp)
	app.register_blueprint(static_bp)
	app.register_blueprint(event_bp)
	app.register_blueprint(daboard_bp)

	return app, db

app, db = create_app()

from db import Personnel

with app.app_context():
	if not Personnel.query.first():
		db.session.add(Personnel(
			photo='mrf.png',
			cin='HH123456',

			first_name='Marouane',
			last_name='MORFI',
			reg_num='IT123456',
			phone='0620550787',
			email='marouanemorfi@gmail.com',
			password=bcrypt.generate_password_hash('123456').decode('utf-8'),

			deleted=False,
			is_admin=True
		))
		db.session.commit()
		print('\033[92m + Default user inserted successfully\033[0m')
	else:
		print('\033[94m - Default user already exists\033[0m')

if __name__ == '__main__':
	app.run(debug=True)