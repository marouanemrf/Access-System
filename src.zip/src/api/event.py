from db import Event, Personnel, db
from flask import Blueprint, request, jsonify, render_template, session, redirect
from datetime import datetime, timedelta
from sqlalchemy import func, cast, Integer
from cloudinary.utils import cloudinary_url
import sign_in
import smtplib
from email.mime.text import MIMEText
from dotenv import load_dotenv
import os

event_bp = Blueprint('eventPage', __name__)

@event_bp.route('/events')
def events():
    reg_num = session.get('user')

    if not reg_num:
        return redirect('/sign-in')  

    user = Personnel.query.filter_by(reg_num=reg_num).first()
    
    if user is None:
        return redirect('/sign-in')  
    
    return render_template('events.html', user=user, cloudinary_url=cloudinary_url, page='events')

@event_bp.route('/getPersonnel', methods=['GET'])
def get_personnel():
    try:
        personnel = Personnel.query.with_entities(Personnel.reg_num, Personnel.first_name, Personnel.last_name).all()
        employees = {p.reg_num: f"{p.first_name} {p.last_name}" for p in personnel}
        
        return jsonify(employees=employees), 200
    except Exception as e:
        return jsonify(error=str(e)), 500
    
@event_bp.route('/insertEvent', methods=['POST'])
def event_inserted():
    try:
        data = request.get_json()  

        if not isinstance(data, list):
            return jsonify({"error": "Invalid data format, expected a list."}), 400
        
        listStarthour = []
        listEndhour = []
        
        for entry in data:
            name = entry.get('NameEvent')
            day = entry.get('day')
            start_hour = entry.get('from')
            end_hour = entry.get('to')
            date = entry.get('date')
            invited = entry.get('invited')
            
            listStarthour.append(start_hour)
            listEndhour.append(end_hour)
            
            for reg_num in invited:
                existing_event = Event.query.filter_by(
                    reg_num=reg_num,
                    day=day,
                    date=date,
                    start_hour=start_hour,
                    end_hour=end_hour
                ).first()

                if existing_event:
                    personnel_exist = Personnel.query.filter_by(reg_num=reg_num).first()
                    namePersonnel = f'{personnel_exist.first_name} {personnel_exist.last_name}'
                    return jsonify({'invited': 'already exists!', 'conflicts': [namePersonnel]}), 409
                
                for hour in range(int(start_hour.split(':')[0]), int(end_hour.split(':')[0])):
                    new_event = Event(
                        event=name,
                        day=day,
                        start_hour=f"{hour:02}:00",
                        end_hour=f"{hour+1:02}:00",
                        date=date, 
                        reg_num=reg_num  
                    )
                    db.session.add(new_event)
            
            personnel = Personnel.query.filter_by(reg_num=reg_num).first()
        
        if personnel:
            to_email = personnel.email  
            full_name = f'{personnel.first_name} {personnel.last_name}'
            
            min_start_hour = min(listStarthour)
            max_end_hour = max(listEndhour)
            
            send_email(
                to_email=to_email, 
                full_name=full_name, 
                startTime=min_start_hour, 
                endtime=max_end_hour, 
                date=date, 
                eventname=name
            )

        db.session.commit()  

        return jsonify({"message": "Event inserted successfully!"}), 200

    except Exception as e:
        db.session.rollback()  
        return jsonify({"error": str(e)}), 500

def send_email(to_email, full_name, startTime, endtime, date, eventname):
    smtp_server = os.getenv('SMTP_SERVER')
    smtp_port = int(os.getenv('SMTP_PORT', 587)) 
    smtp_user = os.getenv('SMTP_USER')
    smtp_password = os.getenv('SMTP_PASSWORD')

    if not all([smtp_server, smtp_port, smtp_user, smtp_password]):
        print("Les paramètres SMTP ne sont pas correctement configurés.")
        return False

    msg = MIMEText(f'Dear {full_name}, \n\nYou are invited to a {eventname} on {date}, from {startTime} to {endtime}.\n\nBest regards,\nOCP Workflow Team')
    msg["Subject"] = f'Invitation to {eventname}'
    msg["From"] = smtp_user
    msg["To"] = to_email

    try:
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.ehlo()  
            server.starttls()  
            server.ehlo()  
            server.login(smtp_user, smtp_password)  
            server.sendmail(smtp_user, to_email, msg.as_string())  
        print("Email sent successfully!")
        return True
    except smtplib.SMTPException as e:
        print(f"Failed to send email: {e}")
        return False
    
@event_bp.route('/getEvents', methods=['GET'])
def get_events():
    try:
        date_start = request.args.get('datefrom')
        date_end = request.args.get('dateend')
        
        date_start = datetime.strptime(date_start, '%Y-%m-%d').date()
        date_end = datetime.strptime(date_end, '%Y-%m-%d').date()
        
        events = Event.query.filter(Event.date.between(date_start, date_end)).all()
        
        event_list = [{
            "id": event.id, 
            "day": event.day,
            "start_hour": event.start_hour,
            "end_hour": event.end_hour,
            "event": event.event,
            "reg_num": event.reg_num
        } for event in events]
        
        return jsonify(events=event_list), 200
    except Exception as e:
        return jsonify(error=str(e)), 500
    
@event_bp.route('/deleteTiming', methods=['POST'])
def deletEvent():
    try:
        data = request.get_json()
        dateStart = data.get('datestart')
        dateend = data.get('dateend')
        day = data.get('day')
        startHour = data.get('from')

        print("Day:", day)
        print("Start Hour:", startHour)
        print("Date Start:", dateStart)
        print("Date End:", dateend)

        events = Event.query.filter(
            Event.day == day,
            Event.start_hour == startHour,
            Event.date.between(dateStart, dateend)
        ).all()

        if not events:
            print("No events found with the given parameters.")
            return jsonify({"error": "No events found to delete."}), 404

        for event in events:
            db.session.delete(event)

        db.session.commit()
        return jsonify({"message": "Event(s) deleted successfully!"}), 200

    except Exception as e:
        db.session.rollback()
        print("Error during deletion:", str(e))
        return jsonify({"error": str(e)}), 500


@event_bp.route('/edit-event')
def edit_event():
    event_id = request.args.get('id')
    events = Event.query.filter_by(id=event_id).first()
    
    event = Event.query.filter_by(event=events.event, date=events.date, day=events.day).with_entities(
        Event.event,
        Event.date,
        Event.day
    ).first()
    print(event)
    
    eventStart = Event.query.filter_by(event=event.event, date=event.date, day=event.day)\
                            .with_entities(func.min(cast(Event.start_hour, Integer)).label('min_start')).scalar()
    eventEnd = Event.query.filter_by(event=event.event, date=event.date, day=event.day)\
                          .with_entities(func.max(cast(Event.end_hour, Integer)).label('max_end')).scalar()
                          
    eventStart = f'{eventStart:02}:00'
    eventEnd = f'{eventEnd:02}:00'
    
    event_invited = Event.query.filter_by(event=events.event, date=events.date, day=events.day).with_entities(Event.reg_num).all()
    
    reg_nums = [inv.reg_num for inv in event_invited]
    print('reg_num: ', reg_nums)
    
    visitors = Personnel.query.filter(Personnel.reg_num.in_(reg_nums)).all()
    
    print(f"Received event_id: {event_id}, employee: {visitors} ")
    
    reg_num = session.get('user')

    if not reg_num:
        return redirect('/sign-in')  

    user = Personnel.query.filter_by(reg_num=reg_num).first()
    
    if user is None:
        return redirect('/sign-in')  
    
    return render_template(
        'editEvent.html', 
        user=user,
        event=event, 
        visitors=visitors, 
        starthour=eventStart, 
        endHour=eventEnd, 
        cloudinary_url=cloudinary_url
    )

    
# @event_bp.route('/update_event', methods=['POST'])
# def update_event():
#     try:
#         event_id = request.args.get('id')
#         event = Event.query.filter(id=event_id).first()
        
#         name = request.form['event_name']
#         date = request.form['date']
#         day = request.form['day']
#         start_hour = request.form['startHour']
#         end_hour = request.form['endHour']
        
#         Event.query.filter(
#             event=event.event,
#             date=event.date,
#             day=event.day
#         ).delete()
        
#         db.session.commit()
        
#         for hour in range(int(start_hour.split(':')[0]), int(end_hour.split(':')[0])):
#             new_data = Event(
#                 event=name,
#                 date=date,
#                 day=day,
#                 start_hour=f"{hour:02}:00",
#                 end_hour=f"{hour+1:02}:00",
#                 reg_num=event.reg_num
#             )
#             db.session.add(new_data)
            
#         db.session.commit()
#         return jsonify({"message": "Event updated successfully!"}), 200
#     except Exception as e:
#         db.session.rollback()
#         return jsonify({"error": str(e)}), 500
    
# @event_bp.route('/delete_visitor', methods=['POST'])
# def delete_visitor():
#     try:
#         event_id = request.args.get('id')
#         event = Event.query.filter(id=event_id).first()
#         event = Event.query.filter_by(id=event_id, reg_num=event.reg_num).first()
#         if not event:
#             return jsonify({"error": "Visitor not found for this event."}), 404

#         db.session.delete(event)
#         db.session.commit()
#         return jsonify({"message": "Visitor removed successfully!"}), 200

#     except Exception as e:
#         db.session.rollback()
#         return jsonify({"error": str(e)}), 500
