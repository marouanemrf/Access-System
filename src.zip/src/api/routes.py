from flask import Blueprint, request, jsonify, render_template, session, redirect, url_for
from db import Personnel, TimeTable, db
import cloudinary
from cloudinary.utils import cloudinary_url
import secrets
from init import bcrypt
import json
import hashlib
import sign_in
import os
from werkzeug.utils import secure_filename


def generate_8_digit_hash(value):
	return hashlib.md5(str(value).encode()).hexdigest()[:8]



####### GENERAL ROUTES #######
# Combine all the general routes into a single blueprint
general_bp = Blueprint('general_routes', __name__)
@general_bp.route('/ping')
def ping():
	print('\033[92m + Pong\033[0m')
	return 'Pong', 200

@general_bp.route('/exit')
def exit():
	session.clear()
	db.session.remove()
	print('\033[93m - Session cleared successfully\033[0m')
	quit()


employee_bp = Blueprint('employee_routes', __name__)

@employee_bp.route('/manage-employees')
def manage_employees():
    reg_num = session.get('user')

    if not reg_num:
        return redirect('/sign-in')  

    user = Personnel.query.filter_by(reg_num=reg_num).first()

    if user is None:
        return redirect('/sign-in') 
    
    employees = Personnel.query.filter_by(deleted=False).all()
    
    return render_template('manage.html', user=user, employees=employees, cloudinary_url=cloudinary_url, page='employees')

@employee_bp.route('/trash-bin')
def trash():
    reg_num = session.get('user')

    if not reg_num:
        return redirect('/sign-in')  

    user = Personnel.query.filter_by(reg_num=reg_num).first()

    if user is None:
        return redirect('/sign-in') 
    
    employees = Personnel.query.filter_by(deleted=True).all()
    
    return render_template('trash.html', user=user, employees=employees, cloudinary_url=cloudinary_url, page='trash')

@employee_bp.route('/AddPage')
def enterToPage():
    reg_num = session.get('user')

    if not reg_num:
        return redirect('/sign-in')  

    user = Personnel.query.filter_by(reg_num=reg_num).first()

    if user is None:
        return redirect('/sign-in') 
    
    employees = Personnel.query.filter_by(deleted=True).all()
    
    return render_template('addEMP.html', user=user, employees=employees, cloudinary_url=cloudinary_url, page='employees')

UPLOAD_FOLDER = r'C:\Users\marou\OneDrive\Desktop\OCP-Workflow-mrf\faces'
UPLOAD_FOLDER1 = r'C:\Users\marou\OneDrive\Desktop\OCP-Workflow-mrf\src\api\static\images'

@employee_bp.route('/Addemployee', methods=['POST'])
def addEMP():
    try:
        firstName = request.form.get('first_name')
        lastName = request.form.get('last_name')
        cin = request.form.get('cin')
        phone = request.form.get('phone')
        email = request.form.get('email')
        photo_file = request.files.get('photo')
        reg_num = generate_8_digit_hash(cin)

        password = bcrypt.generate_password_hash(cin).decode('utf-8')  

        if not photo_file or photo_file.filename == '':
            return jsonify({'message': 'No file uploaded'}), 400

        filename = secure_filename(photo_file.filename)
        extension = os.path.splitext(filename)[1]
        new_filename = f"{reg_num}{extension}"
        subdirectory_path = os.path.join(UPLOAD_FOLDER, reg_num)
        os.makedirs(subdirectory_path, exist_ok=True)

        save_path = os.path.join(subdirectory_path, new_filename)
        save_path1 = os.path.join(UPLOAD_FOLDER1, new_filename)

        photo_file.save(save_path)
        photo_file.save(save_path1)

        backup_folder = os.path.join(UPLOAD_FOLDER, 'backup')
        os.makedirs(backup_folder, exist_ok=True)
        backup_photo_path = os.path.join(backup_folder, new_filename)
        with open(save_path, 'rb') as src_file:
            with open(backup_photo_path, 'wb') as dest_file:
                dest_file.write(src_file.read())

        check_cin = Personnel.query.filter_by(cin=cin).first()
        if check_cin:
            return jsonify({'message': 'The CIN already exists'}), 400

        add_EMP = Personnel(
            first_name=firstName,
            last_name=lastName,
            cin=cin,
            phone=phone,
            email=email,
            photo=new_filename,
            reg_num=reg_num,
            password=password,  
            deleted=False,
            is_admin=False
        )
        
        db.session.add(add_EMP)
        db.session.commit()

        return jsonify({'message': 'Employee added successfully', 'reg_num': reg_num}), 201

    except Exception as e:
        print(f"Error occurred: {e}")
        return jsonify({'message': 'Internal Server Error', 'error': str(e)}), 500


@employee_bp.route('/sendToTrash/<cin>', methods=['POST'])
def sendToTrash(cin):
    try:
        employee = Personnel.query.filter_by(cin=cin).first()
        
        if not employee:
            return redirect(url_for('employee_routes.manage_employees'))
        
        employee.deleted = True
        
        if employee.photo:
            old_photo_path = os.path.join(UPLOAD_FOLDER, employee.reg_num, employee.photo)
            if os.path.exists(old_photo_path):
                os.remove(old_photo_path)
                
        subdirectory_path = os.path.join(UPLOAD_FOLDER, employee.reg_num)
        if os.path.exists(subdirectory_path) and not os.listdir(subdirectory_path):
            os.rmdir(subdirectory_path)

        db.session.commit()
        
        return redirect(url_for('employee_routes.trash'))

    except Exception as e:
        print(f"Error occurred: {e}")
        return redirect(url_for('employee_routes.manage_employees'))

    
@employee_bp.route('/restore-employee/<cin>', methods=['POST'])
def restore_employee(cin):
    try:
        employee = Personnel.query.filter_by(cin=cin).first()

        if not employee:
            return redirect(url_for('employee_routes.trash'))

        employee.deleted = False

        subdirectory_path = os.path.join(UPLOAD_FOLDER, employee.reg_num)
        os.makedirs(subdirectory_path, exist_ok=True)

        if employee.photo:
            backup_folder = os.path.join(UPLOAD_FOLDER, 'backup')
            backup_photo_path = os.path.join(backup_folder, employee.photo)
            save_path = os.path.join(subdirectory_path, employee.photo)
            save_path1 = os.path.join(UPLOAD_FOLDER1, employee.photo)

            if os.path.exists(backup_photo_path):
                with open(backup_photo_path, 'rb') as src_file:
                    with open(save_path, 'wb') as dest_file:
                        dest_file.write(src_file.read())

                with open(backup_photo_path, 'rb') as src_file:
                    with open(save_path1, 'wb') as dest_file:
                        dest_file.write(src_file.read())

        db.session.commit()

        return redirect(url_for('employee_routes.manage_employees'))

    except Exception as e:
        print(f"Error occurred: {e}")
        return redirect(url_for('employee_routes.trash'))

    
@employee_bp.route('/deleteEMP/<cin>', methods=['POST'])
def delete(cin):
    try:
        employee = Personnel.query.filter_by(cin=cin).first()
        if not employee:
            return redirect(url_for('employee_routes.trash'))
        
        
        if employee.photo:
            photo_path = os.path.join(UPLOAD_FOLDER, employee.reg_num, employee.photo)
            if os.path.exists(photo_path):
                os.remove(photo_path)

            photo_path1 = os.path.join(UPLOAD_FOLDER1, employee.photo)
            if os.path.exists(photo_path1):
                os.remove(photo_path1)

            subdirectory_path = os.path.join(UPLOAD_FOLDER, employee.reg_num)
            if os.path.exists(subdirectory_path) and not os.listdir(subdirectory_path):
                os.rmdir(subdirectory_path)
        
        db.session.delete(employee)
        db.session.commit()
        
        return redirect(url_for('employee_routes.trash'))
    except Exception as e:
        print(f"Error occurred: {e}")
        return redirect(url_for('employee_routes.trash'))
    
    
@employee_bp.route('/details/<cin>')
def details(cin):
    reg_num = session.get('user')

    if not reg_num:
        return redirect('/sign-in')  
    
    user = Personnel.query.filter_by(reg_num=reg_num).first()
    employee = Personnel.query.filter_by(cin=cin).first()

    if not employee:
        return redirect(url_for('employee_routes.manage_employees'))

    return render_template('edit.html', user=user, employee=employee, cloudinary_url=cloudinary_url, page='employees')

@employee_bp.route('/update_employee/<reg_num>', methods=['POST'])
def update_employee(reg_num):
    try:
        employee = Personnel.query.filter_by(reg_num=reg_num).first()
        if not employee:
            return jsonify({'message': 'Employee not found'}), 404

        employee.first_name = request.form.get('first_name')
        employee.last_name = request.form.get('last_name')
        employee.cin = request.form.get('cin')
        employee.phone = request.form.get('phone')
        employee.email = request.form.get('email')

        photo_file = request.files.get('photo')
        if photo_file and photo_file.filename != '':
            if employee.photo:
                old_photo_path = os.path.join(UPLOAD_FOLDER, employee.reg_num, employee.photo)
                old_photo_path1 = os.path.join(UPLOAD_FOLDER1, employee.photo)
                if os.path.exists(old_photo_path):
                    os.remove(old_photo_path)
                if os.path.exists(old_photo_path1):
                    os.remove(old_photo_path1)

            filename = secure_filename(photo_file.filename)
            extension = os.path.splitext(filename)[1]
            new_filename = f"{reg_num}{extension}"
            subdirectory_path = os.path.join(UPLOAD_FOLDER, reg_num)
            os.makedirs(subdirectory_path, exist_ok=True)
            save_path = os.path.join(subdirectory_path, new_filename)
            save_path1 = os.path.join(UPLOAD_FOLDER1, new_filename)
            photo_file.save(save_path)
            photo_file.save(save_path1)

            backup_folder = os.path.join(UPLOAD_FOLDER, 'backup')
            backup_photo_path = os.path.join(backup_folder, new_filename)
            with open(save_path, 'rb') as src_file:
                with open(backup_photo_path, 'wb') as dest_file:
                    dest_file.write(src_file.read())

            employee.photo = new_filename

        db.session.commit()

        return jsonify({'message': 'Employee updated successfully'}), 200

    except Exception as e:
        print(f"Error occurred: {e}")
        return jsonify({'message': 'Internal Server Error'}), 500

@employee_bp.route('/Time_Table/<cin>')
def Time_Table(cin):
    reg_num = session.get('user')

    if not reg_num:
        return redirect('/sign-in')  
    
    user = Personnel.query.filter_by(reg_num=reg_num).first()
    employee = Personnel.query.filter_by(cin=cin).first()

    if not employee:
        return redirect(url_for('employee_routes.manage_employees'))

    return render_template('timetable.html', user=user, employee=employee, cloudinary_url=cloudinary_url, page='employees')

@employee_bp.route('/InsertTime/<reg_num>', methods=['POST'])
def InsertTime(reg_num):
    try:
        data = request.get_json()
        
        for entry in data:
            day = entry.get('day')
            time_in = entry.get('time_in')
            time_off = entry.get('time_off')
            
            print(day, time_in, time_off)

            existing_entry = TimeTable.query.filter_by(
                personnel_reg_num=reg_num,
                day=day,
                time_in=time_in,
                time_off=time_off
            ).first()

            if existing_entry:
                print(f"Time entry for {day} from {time_in} to {time_off} already exists.")
                continue  

            time_Table = TimeTable(
                personnel_reg_num=reg_num,
                day=day,
                time_in=time_in,
                time_off=time_off
            )
            
            db.session.add(time_Table)
        
        db.session.commit()
        
        return jsonify({'message': 'Time inserted successfully'}), 200
        
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'message': 'Internal Server Error'}), 500

    
@employee_bp.route('/getData/<employeeNum>', methods=['GET'])
def get_data(employeeNum):
    try:
        timing = TimeTable.query.filter_by(personnel_reg_num=employeeNum).all()

        workeTime = [{
            "day": i.day,
            "time_in": str(i.time_in),
            "time_off": str(i.time_off),
        } for i in timing]
        
        print(workeTime)
    
        return jsonify({'time': workeTime})
    except Exception as e:
        print(f"An error occurred: {e}")
        return jsonify({'error': str(e)}), 500
    
@employee_bp.route('/delete/<reg_num>', methods=['POST'])
def deleteTime(reg_num):
    try:
        data = request.get_json()
        hour = data.get('start_hour')
        day = data.get('day')
        
        timeWork = TimeTable.query.filter_by(
			personnel_reg_num=reg_num,
			day=day,
			time_in=hour
		).first()
        
        db.session.delete(timeWork)
        db.session.commit()
        
        return jsonify({'message': 'Time deleted successfully'}), 200
    except Exception as e:
        return jsonify({'error': e})
