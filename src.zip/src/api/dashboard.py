from flask import Blueprint, session, render_template, redirect
from cloudinary.utils import cloudinary_url
from db import db, Personnel, Event, TimeTable, Event, DurationWorked
from sqlalchemy import func

daboard_bp = Blueprint('DashBoard', __name__)

def to_hour(column):
    return func.cast(func.substr(column, 1, 2), db.Integer)

def parse_duration(duration_str):
    h, m, s = map(float, duration_str.split(':'))
    total_hours = h + (m / 60) + (s / 3600)
    return total_hours

@daboard_bp.route('/dashboard')
def dashboard():
    reg_num = session.get('user')

    if not reg_num:
        return redirect('/sign-in')  

    user = Personnel.query.filter_by(reg_num=reg_num).first()
    
    if user is None:
        return redirect('/sign-in')  
    total_employees = Personnel.query.filter_by(deleted=False).count()
    total_event = Event.query.group_by(Event.event).count()
    total_workTime = TimeTable.query.count()
    
    total_events_time = db.session.query(
        func.sum(
            Event.end_hour - Event.start_hour
        )
    ).scalar()    
    durations = db.session.query(DurationWorked.duration).all()
    total_DurationWorked = sum(parse_duration(duration[0]) for duration in durations)
    total_DurationWorked = round(total_DurationWorked, 1)    
    Admins = Personnel.query.filter_by(is_admin=True)
    new_EMP = Personnel.query.filter_by(deleted=False).order_by(Personnel.reg_num.desc()).limit(6).all()
    new_events = db.session.query(
        Event.event,
        func.min(Event.start_hour).label('startHour'),
        func.max(Event.end_hour).label('endHour'),
        Event.date
    ).group_by(Event.event).order_by(func.max(Event.date).desc()).limit(6).all()    
    
    total_time = total_workTime + total_DurationWorked
    if total_time == 0:
        WorkTime_perc = Duration_perc = 0
    else:
        WorkTime_perc = (total_workTime / total_time) * 100
        Duration_perc = (total_DurationWorked / total_time) * 100
    
    timings = TimeTable.query.join(Personnel, TimeTable.personnel_reg_num == Personnel.reg_num)\
        .add_columns(Personnel.first_name, Personnel.last_name, TimeTable.day, TimeTable.time_in, TimeTable.time_off)\
            .all()
    
    data = {}
    
    for timing in timings:
        day = timing.day
        if day not in data:
            data[day] = []
        data[day].append({
            'employee': f"{timing.first_name} {timing.last_name}",
            'time_in': timing.time_in,
            'time_off': timing.time_off
        })
     
    return render_template(
        'dashboard.html',
        data=data,
        new_EMP=new_EMP,
        new_events=new_events,
        WorkTime_perc=WorkTime_perc,
        Duration_perc=Duration_perc,
        Admins=Admins,
        total_DurationWorked=total_DurationWorked,
        total_EventsTime=total_events_time,
        total_workTime=total_workTime,
        total_event=total_event,
        total_employees=total_employees,
        cloudinary_url=cloudinary_url,
        user=user,
        page='dashboard'
    )
