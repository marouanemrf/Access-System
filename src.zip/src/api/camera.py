from flask import Flask, Blueprint, request, jsonify, render_template
import numpy as np
import base64
from io import BytesIO
from PIL import Image
import face_recognition
import os
import glob
from datetime import datetime, timedelta
from db import DurationWorked, db, Personnel
from sqlalchemy import and_

known_faces = []
known_names = []
face_detected_time = None
face_detected_timeLeaving = None
arrive = []
depart = []
duration_list = []
day_in = None
day_off = None
faces_folder = 'C:/Users/marou/OneDrive/Desktop/OCP-Workflow-mrf/faces/'

def get_encoding(img):
    image = face_recognition.load_image_file(img)
    face_encoding = face_recognition.face_encodings(image)
    if len(face_encoding) > 0:
        return face_encoding[0]
    return None

def filtering_img(faces_folder):
    if os.path.exists(faces_folder):
        for name in os.listdir(faces_folder):
            images = os.path.join(faces_folder, name, '*.jpg')
            images_path = glob.glob(images)
            for image in images_path:
                encoding = get_encoding(image)
                if encoding is not None:
                    known_faces.append(encoding)
                    known_names.append(name)
                else:
                    print(f"No data found for image: {image}")
    else:
        print(f"Path not found: {faces_folder}")

filtering_img(faces_folder)

cam_bp = Blueprint('frame', __name__)

@cam_bp.route('/frame', methods=['POST'])
def proc_frame():
    global face_detected_time, face_detected_timeLeaving, day
    
    try:
        image_data = request.form['image']
        header, encoded = image_data.split(",", 1)
        decoded = base64.b64decode(encoded)
        image = Image.open(BytesIO(decoded)).convert('RGB')

        frame = np.array(image)
        faces = face_recognition.face_locations(frame)
    
        if not faces:
            return jsonify({"msg": 'No faces detected'})

        names = []
        
        for face in faces:
            encoding = face_recognition.face_encodings(frame, [face])[0]
            matches = face_recognition.compare_faces(known_faces, encoding)
            
            if True in matches:
                first_match = matches.index(True)
                name = known_names[first_match]
                names.append(name)
        
        time_message = update_time(name)
        
        return jsonify({'message': f'Face recognized: {names} matches found', 'timing': time_message})

    except Exception as e:
        return jsonify({'error': f"Internal Server Error: {str(e)}"}), 500

def update_time(face):
    global face_detected_time, face_detected_timeLeaving, day_in, day_off
    
    if face:
        if face_detected_time is None:
            face_detected_time = datetime.now()
            day_in = face_detected_time.date()
            arrive.append(face_detected_time)
             
        else:
            face_detected_timeLeaving = datetime.now()
            day_off = face_detected_timeLeaving.date()
            depart.append(face_detected_timeLeaving)
        
        message = calculate_duration(min(arrive), max(depart), face, day_in, day_off)  
        return message

    return "No face detected"
            
def calculate_duration(arrive, depart, name, day_in, day_off):
    if arrive and depart:
        duration = depart - arrive  
        duration_list.append(duration)
        message = send_to_DB(arrive, depart, name, day_in, day_off, max(duration_list))
        return message
    
    return '_'

from datetime import timedelta

def send_to_DB(arrive, depart, name, day_in, day_off, duration):
    arrive_str = arrive.strftime('%H:%M:%S')
    depart_str = depart.strftime('%H:%M:%S')
    dayIn_str = day_in.strftime('%A')
    dayOff_str = day_off.strftime('%A')
    date = datetime.now()

    duration_seconds = duration.total_seconds()

    arrive_intervale = arrive + timedelta(hours=4)

    existing_data = db.session.query(DurationWorked).filter(
        and_(
            DurationWorked.personnel_reg_num == name,
            DurationWorked.day_in == dayIn_str,
            DurationWorked.time_in >= arrive_str,
            DurationWorked.time_in <= arrive_intervale
        )
    ).first()

    if existing_data:
        H, m, s = map(float, existing_data.duration.split(':'))
        existing_duration = timedelta(minutes=H, seconds=m, milliseconds=s)

        updated_duration = existing_duration + timedelta(seconds=duration_seconds)
        existing_data.day_off = dayOff_str
        existing_data.time_off = depart_str
        existing_data.duration = str(updated_duration)
        existing_data.date = date

        message = f'{name} came at {arrive_str} on {dayIn_str} and left at {depart_str} on {dayOff_str}, duration: {updated_duration} and the day: {date}, Updated!!!!'
    else:
        send = DurationWorked(
            personnel_reg_num=name,
            day_in=dayIn_str,
            day_off=dayOff_str,
            time_in=arrive_str,
            time_off=depart_str,
            duration=str(timedelta(seconds=duration_seconds)),
            date=date
        )
        db.session.add(send)

        message = f'{name} came at {arrive_str} on {dayIn_str} and left at {depart_str} on {dayOff_str}, duration: {duration} and the day: {date}, send!!!!'

    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        return str(e)

    return message
