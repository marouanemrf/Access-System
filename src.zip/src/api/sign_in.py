from flask import Blueprint, request, session, jsonify, render_template, redirect
from cloudinary.utils import cloudinary_url
from init import bcrypt
from db import db, Personnel
import cv2
import os
import glob
import face_recognition
import numpy as np
import time
from dotenv import load_dotenv
import os
import smtplib
from email.mime.text import MIMEText
import string, random

load_dotenv()

sign_in_bp = Blueprint('sign_in', __name__)

@sign_in_bp.route('/sign-in', methods=['GET', 'POST'])
def sign_in_api():
    if request.method == 'POST':
        if not request.is_json:
            return jsonify({'success': False, 'message': 'Content-Type must be application/json'}), 415

        data = request.get_json() 
        reg_num = data.get('reg_num')
        password = data.get('password')

        user = Personnel.query.filter_by(reg_num=reg_num, is_admin=1).first()

        if user is None:
            return jsonify({'success': False, 'message': 'User not found'}), 404
        elif not bcrypt.check_password_hash(user.password, password):
            return jsonify({'success': False, 'message': 'Incorrect password'}), 401

        session['user'] = user.reg_num

        return jsonify({'success': True, 'message': 'Signed in successfully', 'user': user.reg_num}), 200
    else:
        return render_template('sign-in.html')
    
known_faces = []
known_names = []
faces = 'C:/Users/marou/OneDrive/Desktop/OCP-Workflow-mrf/faces/'

def Finding_face():
    for name in os.listdir(faces):
        image_mask = os.path.join(faces, name, '*.jpg')
        image_paths = glob.glob(image_mask)
        for image_path in image_paths:
            encoding = get_encoding(image_path)
            if encoding is not None:
                    known_faces.append(encoding)
                    known_names.append(name)
                    
def get_encoding(img):
    image = face_recognition.load_image_file(img)
    face_encodings = face_recognition.face_encodings(image)
    if len(face_encodings):
        return face_encodings[0]
    return None

Finding_face()

@sign_in_bp.route('/FaceId', methods=['POST'])
def face_login():
    cap = cv2.VideoCapture(0)
    time_out = 5
    start_time = time.time()

    while time.time() - start_time < time_out:
        ret, frame = cap.read()
        if not ret:
            break

        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  
        faces = face_recognition.face_locations(frame_rgb)
        encodings = face_recognition.face_encodings(frame_rgb, faces)
        
        if encodings:
            for encoding in encodings:
                results = face_recognition.compare_faces(known_faces, encoding)
                if True in results:
                    index = results.index(True)
                    reg_num = known_names[index]  
                    
                    user = Personnel.query.filter_by(reg_num=reg_num).first()
                    
                    if user is None:
                        return jsonify({'success': False, 'message': 'User not found'}), 404
                    
                    session['user'] = user.reg_num
                    cap.release()
                    return jsonify({'success': True, 'message': 'Signed in successfully', 'user': user.reg_num}), 200

    cap.release()
    return jsonify({'success': False, 'message': 'Face not recognized'}), 401

@sign_in_bp.route('/forget-password')
def forget_password():
    return render_template('forgetPassword.html')

@sign_in_bp.route('/sendPassword', methods=['POST'])
def handle_forget_password():
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'message': 'No data provided'}), 400
        
        reg_num = data.get('reg_num')
        email = data.get('email')
        
        
        
        if not reg_num or not email:
            return jsonify({'success': False, 'message': 'Registration number and email are required'}), 400
        
        user = Personnel.query.filter_by(reg_num=reg_num, email=email, is_admin=1).first()
        
        if user is not None:
            try:
                verification_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
                
                session['verification_code'] = verification_code
                session['user_email'] = email
                session['reg_num'] = reg_num
                
                success = send_email(
                    to_email=email,
                    subject="Your OCP Account Verification Code",
                    body=f"Dear {user.first_name} {user.last_name},\n\nYour verification code is: {verification_code}\n\nPlease use this code to reset your password.\n\nBest regards,\nOCP Workflow Team"
                )
                if success:
                    print(f"Dear {user.first_name} {user.last_name},\n\nYour password is: {user.password}\n\nPlease keep it secure.\n\nBest regards,\nOCP Workflow Team")
                    return jsonify({'success': True, 'message': 'An email with your password has been sent!'}), 200
                else:
                    return jsonify({'success': False, 'message': 'Failed to send email.'}), 500
            except Exception as e:
                return jsonify({'success': False, 'message': f'Error sending email: {str(e)}'}), 500
        
        return jsonify({'success': False, 'message': 'Invalid registration number or email!'}), 404
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        return jsonify({'success': False, 'message': 'An unexpected error occurred'}), 500

def send_email(to_email, subject, body):
    smtp_server = os.getenv('SMTP_SERVER')
    smtp_port = int(os.getenv('SMTP_PORT', 587))
    smtp_user = os.getenv('SMTP_USER')
    smtp_password = os.getenv('SMTP_PASSWORD')

    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = smtp_user
    msg["To"] = to_email
    
    try:
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()  
            server.login(smtp_user, smtp_password)
            server.sendmail(smtp_user, to_email, msg.as_string())
        print("Email sent successfully!")
        return True
    except Exception as e:
        print(f"Failed to send email: {e}")
        return False
    
@sign_in_bp.route('/resetPassword', methods=['POST'])
def reset_password():
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'message': 'No data provided'}), 400
        
        verification_code = data.get('verification_code')
        new_password = data.get('new_password')
        
        stored_code = session.get('verification_code')
        email = session.get('user_email')
        reg_num = session.get('reg_num')
        
        if not stored_code or not email or not reg_num:
            return jsonify({'success': False, 'message': 'Session data missing. Please retry the process.'}), 400
        
        if verification_code != stored_code:
            return jsonify({'success': False, 'message': 'Invalid verification code!'}), 400

        user = Personnel.query.filter_by(reg_num=reg_num, email=email).first()
    
        if user:
            try:
                hashed_password = bcrypt.generate_password_hash(new_password).decode('utf-8')
                user.password = hashed_password
                
                db.session.commit()
                
                session.pop('verification_code', None)
                session.pop('user_email', None)
                session.pop('reg_num', None)
                
                return jsonify({'success': True, 'message': 'Password updated successfully!'}), 200
            except Exception as e:
                print(f"Error updating password: {str(e)}")
                return jsonify({'success': False, 'message': 'An unexpected error occurred while updating the password.'}), 500
        
        return jsonify({'success': False, 'message': 'User not found!'}), 404
    
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        return jsonify({'success': False, 'message': 'An unexpected error occurred'}), 500


    
@sign_in_bp.route('/camera')
def camera():
    reg_num = session.get('user')

    if not reg_num:
        return redirect('/sign-in')  

    user = Personnel.query.filter_by(reg_num=reg_num).first()
    
    if user is None:
        return redirect('/sign-in')  
    
    return render_template('cameras.html', user=user, cloudinary_url=cloudinary_url, page='cameras')


