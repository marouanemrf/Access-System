from flask import Blueprint, request, session, jsonify, render_template, redirect, url_for
from cloudinary.utils import cloudinary_url
from db import DurationWorked, db, Personnel, TimeTable, Event
from sqlalchemy import func
from datetime import datetime


static_bp = Blueprint('StatStuff', __name__)

def parse_duration(duration_str):
    h, m, s = map(float, duration_str.split(':'))
    total_hours = h + (m / 60) + (s / 3600)
    return total_hours

@static_bp.route('/static/<cin>')
def details(cin):
    reg_num = session.get('user')

    if not reg_num:
        return redirect('/sign-in')  
    
    user = Personnel.query.filter_by(reg_num=reg_num).first()
    employee = Personnel.query.filter_by(cin=cin).first()
    reg_num_employee = employee.reg_num
    
    Total_workTime = TimeTable.query.filter_by(personnel_reg_num=reg_num_employee).count()
    Totale_EventTime = db.session.query(
        func.sum(
            Event.end_hour - Event.start_hour
        )
    ).filter_by(reg_num=reg_num_employee).scalar()
    
    Duration = db.session.query(DurationWorked.duration).filter_by(personnel_reg_num=reg_num_employee).all()
    Total_Duration = sum(parse_duration(i[0]) for i in Duration)
    Total_Duration = round(Total_Duration, 1)
    
    Total_absence = Total_Duration - Total_workTime
    Total_absence = -1 * Total_absence if Total_absence < 0 else Total_absence
    
    total_time = Total_absence + Total_Duration
    if total_time == 0:
        absence_perc = Duration_perc = 0
    else:
        absence_perc = (Total_absence / total_time) * 100
        Duration_perc = (Total_Duration / total_time) * 100
    
    absence_list = getAbsenceList(reg_num_employee)  
    
    if not employee:
        return redirect(url_for('employee_routes.manage_employees'))

    return render_template('stat.html', 
                           user=user, 
                           Total_workTime=Total_workTime,
                           Totale_EventTime=Totale_EventTime,
                           employee=employee, 
                           Total_Duration=Total_Duration,
                           Total_absence=Total_absence,
                           absence_perc=absence_perc,
                           Duration_perc=Duration_perc,
                           absence_list=absence_list,
                           cloudinary_url=cloudinary_url, 
                           page='employees')

@static_bp.route('/Presence/<reg_num>', methods=['GET'])
def PresenceTimeTable(reg_num):
    date_start = request.args.get('date_start')
    date_end = request.args.get('date_end')
    
    TimeTable = DurationWorked.query.filter(DurationWorked.date.between(date_start, date_end), DurationWorked.personnel_reg_num == reg_num).all()
    
    template_data_in = {}
    template_data_off = {}
    
    for duration in TimeTable:
        day_in = duration.day_in
        day_off = duration.day_off
        time_in_slot_hour = duration.time_in.split(':')[0]
        time_off_slot_hour = duration.time_off.split(':')[0]
        time_in_slot = f'{time_in_slot_hour}'
        time_off_slot = f'{time_off_slot_hour}'
        
        template_data_in[f'{day_in}-{time_in_slot}'] = duration.duration 
        template_data_off[f'{day_off}-{time_off_slot}'] = duration.duration 
                
    return jsonify(presenceDataIn=template_data_in, presenceDataOff=template_data_off)

@static_bp.route('/TimeWork/<reg_num>', methods=['POST', 'GET'])
def Time_Work(reg_num):
    Time_Table = TimeTable.query.filter_by(personnel_reg_num=reg_num).all()
    template_data_in = []
    
    for duration in Time_Table:
        day = duration.day
        time_in = duration.time_in.split(':')[0]        
        template_data_in.append(f'{day}-{time_in}')
            
    return jsonify(timeWorkIn=template_data_in)

@static_bp.route('/eventTime/<reg_num>', methods=['GET'])
def EventTime(reg_num):
    date_start = request.args.get('date_start')
    date_end = request.args.get('date_end')
    
    time_table = Event.query.filter(Event.date.between(date_start, date_end), Event.reg_num == reg_num).all()
    template_data_in = []
    
    for duration in time_table:
        day = duration.day
        time_in = duration.start_hour.split(':')[0]
        
        template_data_in.append(f'{day}-{time_in}')
        
    return jsonify(timeEvent_in=template_data_in)

@static_bp.route('/getAbsenceList/<reg_num>', methods=['POST'])
def getAbsenceList(reg_num):
    Times = TimeTable.query.filter_by(personnel_reg_num=reg_num).all()
    Worked_time = DurationWorked.query.filter_by(personnel_reg_num=reg_num).all()
    
    Times_dect = {}
    for time in Times:
        day_in = time.day  
        if day_in not in Times_dect:
            Times_dect[day_in] = []
            
        Times_dect[day_in].append({
            'time_in': time.time_in,
            'time_off': time.time_off
        })
    
    times_list = [{'day': day, 'times': Times_dect[day]} for day in Times_dect]
    
    Worked_time_dect = {}
    for work in Worked_time:
        day_in = work.day_in  
        
        if day_in not in Worked_time_dect:
            Worked_time_dect[day_in] = []
        
        Worked_time_dect[day_in].append({
            'time_in': work.time_in,
            'time_off': work.time_off
        })
    
    work_list = [{'day': day, 'times': Worked_time_dect[day]} for day in Worked_time_dect]

    worked_set = set(
        (entry['day'], time['time_in'], time['time_off'])
        for entry in work_list
        for time in entry['times']
    )
    
    absence_list = []
    for entry in times_list:
        day = entry['day']
        for time in entry['times']:
            if (day, time['time_in'], time['time_off']) not in worked_set:
                absence_list.append({
                    'day': day,
                    'time_in': time['time_in'],
                    'time_off': time['time_off']
                })

    return absence_list
