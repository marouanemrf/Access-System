async function signIn(event) {
    event.preventDefault();

    const reg_num = document.getElementById('reg-num').value;
    const password = document.getElementById('password').value;

    try {
        const response = await fetch('/sign-in', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                reg_num: reg_num,
                password: password,
            })
        });

        const data = await response.json();

        if (data.success) {
            console.log('radkhalet');
            
            window.location.href = '/dashboard';
        } else {
            alert('Login failed: ' + data.message);
        }
    } catch (error) {
        console.error('There was an error!', error);
        alert('An error occurred. Please try again.');
    }
}

async function faceLogin() {
	const feedbackImage = document.getElementById('feedbackImage');
	feedbackImage.src = '/static/images/face-id.png';
    try {
        const response = await fetch('/FaceId', {
            method: 'POST'
        });

        const data = await response.json();
        
		if (data.success) {
            feedbackImage.src = '/static/images/face-id.png'; 
            feedbackImage.style.width = '50px';
            feedbackImage.style.height = '50px';
            feedbackImage.style.objectFit = 'cover';
            window.location.href = '/dashboard';
        } else {
            feedbackImage.src = '/static/images/FalseFace.png'; 
            feedbackImage.style.width = '50px';
            feedbackImage.style.height = '50px';
            feedbackImage.style.objectFit = 'cover';
        }

    } catch (error) {
        console.error('There was an error!', error);
    }
}

function setExpiration(key, value, time) {
    const now = new Date();
    const item = {
        value: value,
        expiry: now.getTime() + time,
    };
    localStorage.setItem(key, JSON.stringify(item));
}

function getExpiration(key) {
    const itemStr = localStorage.getItem(key);
    if (!itemStr) {
        return null;
    }
    const item = JSON.parse(itemStr);
    const now = new Date();

    if (now.getTime() > item.expiry) {
        console.log('rakhdit');
        
        localStorage.removeItem(key);
        return null;
    }
    return item.value;
}

function store() {
    console.log('dddddxxd')
    const reg_num = document.getElementById('reg-num').value;
    const password = document.getElementById('password').value;
    const rememberMe = document.getElementById('remember-me').checked;

    if (rememberMe) {
        console.log('dddd')
        setExpiration('reg_num', reg_num, 86400000); 
        setExpiration('password', password, 86400000); 
    } else {
        localStorage.removeItem('reg_num');
        localStorage.removeItem('password');
    }
}

document.getElementById('loginButton').addEventListener('click', signIn);
document.getElementById('face-id-btn').addEventListener('click', faceLogin);
document.addEventListener('DOMContentLoaded', faceLogin);

document.addEventListener('DOMContentLoaded', () => {
    const storedRegNum = getExpiration('reg_num');
    const storedPassword = getExpiration('password');
    if (storedRegNum && storedPassword) {
        document.getElementById('reg-num').value = storedRegNum;
        document.getElementById('password').value = storedPassword;
        document.getElementById('remember-me').checked = true;
    }
});

document.getElementById('remember-me').addEventListener('click', ()=> {
    store();
})

document.getElementById('sign-in-form').addEventListener('submit', (e) => {
    e.preventDefault();
    
    signIn(e);
    
});
