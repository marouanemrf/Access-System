function handleCard() {
    var card = document.getElementById("card");
    card.style.display = "block";

    var opF = document.getElementById('from');
    var opT = document.getElementById('to');

    opF.innerHTML = '';
    opT.innerHTML = '';

    for (let i = 0; i < 24; i++) {
        var optionT = document.createElement('option');
        let hour = i < 10 ? '0' + i : i;
        optionT.value = optionT.text = `${hour}:00`;
        opF.appendChild(optionT);
        opT.appendChild(optionT.cloneNode(true));
    }
}

function fetching_data() {
    const dateInputfrom = document.getElementById("datefrom");
    const dateInputend = document.getElementById("dateend");
    
    const selectedDatestart = dateInputfrom.value;
    const selectedDateend = dateInputend.value;

    fetch(`/getEvents?datefrom=${selectedDatestart}&dateend=${selectedDateend}`)
        .then(response => response.json())
        .then(data => {
            const events = data.events;

            document.querySelectorAll('td').forEach(td => {
                td.classList.remove('filled');
                td.style.backgroundColor = '';
                const buttons = td.querySelectorAll('button');
                buttons.forEach(button => button.remove());
            });

            events.forEach(event => {
                const day = event.day;
                const startHour = event.start_hour.split(':')[0];
                const formattedHour = startHour.length === 1 ? '0' + startHour : startHour;
                const cellID = `${day}-${formattedHour}`;
                const cell = document.getElementById(cellID);

                if (cell) {
                    cell.classList.add('filled');
                    cell.style.backgroundColor = 'green';

                    if (!cell.querySelector('.trash')) {
                        const trash = document.createElement('button');
                        trash.className = 'trash';
                        trash.addEventListener("click", () => handleDelete(day, startHour, selectedDatestart, selectedDateend));
                        cell.appendChild(trash);  
                    }

                    if (!cell.querySelector('.view')) {
                        const view = document.createElement('button');
                        view.className = 'view';
                        view.addEventListener("click", () => {
                            if (event.id) {  
                                window.location.href = `/edit-event?id=${event.id}`;
                            } else {
                                alert('Event ID is not available.');
                            }
                        });               
                        cell.appendChild(view);  
                    }
                    
                } else {
                    console.error(`Cell with ID ${cellID} not found.`);
                }
            });
        })
        .catch(error => console.error("Error fetching events: ", error));
};

document.addEventListener("DOMContentLoaded", function () {
    let employees = {};

    fetch("/getPersonnel")
        .then(response => response.json())
        .then(data => {
            employees = data.employees;  

            function filterEmployees() {
                const input = document.getElementById("employeeInput");
                const dropdown = document.getElementById("autocompleteDropdown");
                const filter = input.value.toLowerCase();

                dropdown.innerHTML = ""; 

                if (filter) {
                    const filteredEmployees = Object.entries(employees).filter(([reg_num, name]) => name.toLowerCase().includes(filter));

                    filteredEmployees.forEach(([reg_num, name]) => {
                        const option = document.createElement("div");
                        option.className = "option";
                        option.textContent = name;
                        option.onclick = () => addEmployeeTag(reg_num, name);
                        dropdown.appendChild(option);
                    });
                }
            }

            function handleEmployeeInput(event) {
                const input = document.getElementById("employeeInput");

                if (event.key === "Enter") {
                    const value = input.value.trim();
                    const matchedEntry = Object.entries(employees).find(([reg_num, name]) => name === value);
                    
                    if (matchedEntry && !isEmployeeAlreadyAdded(matchedEntry[0])) {
                        addEmployeeTag(matchedEntry[0], matchedEntry[1]);
                    }
                    input.value = ""; 
                    event.preventDefault();
                }
            }

            function addEmployeeTag(reg_num, name) {
                if (!isEmployeeAlreadyAdded(reg_num)) {
                    const input = document.getElementById("employeeInput");
                    const tag = document.createElement("span");
                    tag.className = "tag";
                    tag.textContent = name;
                    tag.dataset.regnum = reg_num;  

                    const removeTag = document.createElement("span");
                    removeTag.className = "remove-tag";
                    removeTag.textContent = "x";
                    removeTag.onclick = () => tag.remove();

                    tag.appendChild(removeTag);
                    input.before(tag);

                    document.getElementById("autocompleteDropdown").innerHTML = "";
                }
            }

            function isEmployeeAlreadyAdded(reg_num) {
                const tags = document.querySelectorAll(".multi-select-input .tag");
                for (let tag of tags) {
                    if (tag.dataset.regnum === reg_num) {
                        return true;
                    }
                }
                return false;
            }

            document.getElementById("employeeInput").addEventListener("input", filterEmployees);
            document.getElementById("employeeInput").addEventListener("keydown", handleEmployeeInput);

        })
        .catch(error => console.error("Error fetching employees:", error));

    const dateInputfrom = document.getElementById("datefrom");
    const dateInputend = document.getElementById("dateend");

    const today = new Date().toISOString().split('T')[0];
    dateInputfrom.value = today;

    const nextWeek = new Date(new Date().setDate(new Date().getDate() + 6));
    dateInputend.value = nextWeek.toISOString().split('T')[0];

    dateInputfrom.addEventListener("change", fetching_data);
    dateInputend.addEventListener("change", fetching_data);

    fetching_data(); 
});

document.querySelector('form').addEventListener('submit', function (event) {
    event.preventDefault();

    const eventName = document.getElementById('eventname').value;
    const date = document.getElementById('dateAdd').value;
    const day = document.getElementById('day').value;
    const startHour  = document.getElementById('from').value;
    const endHour = document.getElementById('to').value;
    const invitedTags = document.querySelectorAll('.multi-select-input .tag');
    const invited = Array.from(invitedTags).map(tag => tag.dataset.regnum);

    const FromHour = parseInt(startHour.split(':')[0]);
    const ToHour = parseInt(endHour.split(':')[0]);

    const timetableEntries = [];

    function getNextDay(currentDay) {
        const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
        const currentIndex = daysOfWeek.indexOf(currentDay);
        const nextIndex = (currentIndex + 1) % daysOfWeek.length;
        return daysOfWeek[nextIndex];
    }

    if (FromHour >= ToHour) {
        for (let hour = FromHour; hour < 24; hour++) {
            const entry = {
                NameEvent: eventName,
                day: day,
                from: `${hour < 10 ? '0' + hour : hour}:00`,
                to: `${hour + 1 < 10 ? '0' + (hour + 1) : hour + 1}:00`,
                date: date,
                invited: invited
            };
            timetableEntries.push(entry);
        }
        
        const nextDay = getNextDay(day);
        for (let hour = 0; hour < ToHour; hour++) {
            const entry = {
                NameEvent: eventName,
                day: nextDay,
                from: `${hour < 10 ? '0' + hour : hour}:00`,
                to: `${hour + 1 < 10 ? '0' + (hour + 1) : hour + 1}:00`,
                date: date,
                invited: invited
            };
            timetableEntries.push(entry);
        }
    } else {
        for (let hour = FromHour; hour < ToHour; hour++) {
            const entry = {
                NameEvent: eventName,
                day: day,
                from: `${hour < 10 ? '0' + hour : hour}:00`,
                to: `${hour + 1 < 10 ? '0' + (hour + 1) : hour + 1}:00`,
                date: date,
                invited: invited
            };
            timetableEntries.push(entry);
        }
    }

    fetch('/insertEvent', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(timetableEntries)  
    })
    .then(response => {
        if (!response.ok) {
            return response.text().then(text => { 
                throw new Error(text); 
            });
        }
        return response.json();
    })
    .then(data => {
        if (data.message) {
            alert("Event inserted successfully!");
            document.getElementById("card").style.display = "none";
            fetching_data(); 
        } else {
            alert("Error inserting event: " + data.error);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert("An error occurred: " + error.message);
    });
});

function handleDelete(day, from, datestart, dateend) {
    const formattedFrom = `${from}:00`;

    fetch('/deleteTiming', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            day: day,
            from: formattedFrom,
            datestart: datestart,
            dateend: dateend
        })
    })
    .then(response => {
        return response.json();
    })
    .then(data => {
        if (data.message) {
            alert("Event(s) deleted successfully!");
            fetching_data(); 
        } else {
            alert("Error deleting event: " + data.error);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert("An error occurred: " + error.message);
    });
}


