document.addEventListener('DOMContentLoaded', () => {
    const submit = document.getElementById('btn');

    submit.addEventListener('click', (event) => {
        event.preventDefault();

        const firstName = document.getElementById('first-name').value.trim();
        const lastName = document.getElementById('last-name').value.trim();
        const cin = document.getElementById('cin').value.trim();
        const phone = document.getElementById('phone').value.trim();
        const email = document.getElementById('email').value.trim();
        const photo = document.getElementById('photo').files[0];

        if (!/^[A-Za-z]{3,}$/.test(firstName) ||
            !/^[A-Za-z]{3,}$/.test(lastName) ||
            !/^[A-Z]{1,2}[0-9]{6}$/.test(cin) ||
            !/^[0-9]{10}$/.test(phone) ||
            !/\S+@\S+\.\S+/.test(email) ||
            !photo) {
            alert('Please fill out all fields correctly.');
            return;
        }

        const formData = new FormData();
        formData.append('first_name', firstName);
        formData.append('last_name', lastName);
        formData.append('cin', cin);
        formData.append('phone', phone);
        formData.append('email', email);
        formData.append('photo', photo);

        fetch('/Addemployee', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Employee added successfully') {
                alert('Employee added successfully! Registration number: ' + data.reg_num);
                window.location.href = '/manage-employees';  
                
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while adding the employee.');
        });


    });

});

document.addEventListener('DOMContentLoaded', function() {
    const submitButton = document.getElementById('btnUpdate');

    submitButton.addEventListener('click', function(event) {
        event.preventDefault(); 

        const firstName = document.getElementById('first-name').value.trim();
        const lastName = document.getElementById('last-name').value.trim();
        const cin = document.getElementById('cin').value.trim();
        const phone = document.getElementById('phone').value.trim();
        const email = document.getElementById('email').value.trim();
        const photo = document.getElementById('photo').files[0];  

        if (!/^[A-Za-z]{3,}$/.test(firstName) ||
            !/^[A-Za-z]{3,}$/.test(lastName) ||
            !/^[A-Z]{1,2}[0-9]{6}$/.test(cin) ||
            !/^[0-9]{10}$/.test(phone) ||
            !/\S+@\S+\.\S+/.test(email)) {
            alert('Please fill out all fields correctly.');
            return;
        }

        const formData = new FormData();
        formData.append('first_name', firstName);
        formData.append('last_name', lastName);
        formData.append('cin', cin);
        formData.append('phone', phone);
        formData.append('email', email);
        if (photo) {
            formData.append('photo', photo);  
        }

        fetch(`/update_employee/${employeeNum}`, {  
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Employee updated successfully') {
                alert('Employee updated successfully!');
                window.location.href = '/manage-employees';  
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while updating the employee.');
        });
    });
});

