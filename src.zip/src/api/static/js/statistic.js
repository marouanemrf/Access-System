document.addEventListener('DOMContentLoaded', () => {
    const date_from = document.getElementById('datefrom');
    const date_end = document.getElementById('dateend');

    const today = new Date().toISOString().split('T')[0];
    date_from.value = today;

    const nextWeek = new Date(new Date().setDate(new Date().getDate() + 6)).toISOString().split('T')[0];
    date_end.value = nextWeek;

    let previousCells = []; 

    const fetchData = () => {
        previousCells.forEach(cell => {
            cell.classList.remove('filled', 'N_filled', 'newFelled');
            cell.style.backgroundColor = '';
        });
        previousCells = []; 

        fetch(`/TimeWork/${employeeNum}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                const timeIn = data.timeWorkIn || [];

                timeIn.forEach(timing => {
                    const CellTimeIn = document.getElementById(timing);
                    if (CellTimeIn) {
                        CellTimeIn.classList.add('filled');
                        CellTimeIn.style.backgroundColor = 'green';
                        previousCells.push(CellTimeIn); 
                    } else {
                        console.log(`id: ${timing} not found`);
                    }
                });
            })
            .catch(error => console.error("Error fetching Time work: ", error));

        fetch(`/eventTime/${employeeNum}?date_start=${date_from.value}&date_end=${date_end.value}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                const timeIn = data.timeEvent_in || [];

                timeIn.forEach(timing => {
                    const CellTimeIn = document.getElementById(timing);
                    if (CellTimeIn) {
                        CellTimeIn.classList.remove('filled');
                        CellTimeIn.classList.add('N_filled');
                        CellTimeIn.style.backgroundColor = '#6CCAA1';
                        previousCells.push(CellTimeIn); 
                    } else {
                        console.log(`id: ${timing} not found`);
                    }
                });
            })
            .catch(error => console.error("Error fetching event time: ", error));

        fetch(`/Presence/${employeeNum}?date_start=${date_from.value}&date_end=${date_end.value}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                const timeInData = data.presenceDataIn;
                const timeOffData = data.presenceDataOff;

                Object.keys(timeInData).forEach(key => {
                    const startday = key.split('-')[0];
                    const startHour = parseInt(key.split('-')[1]);

                    const timeOffKey = Object.keys(timeOffData).find(k => k.startsWith(startday));
                    if (timeOffKey) {
                        const endHour = parseInt(timeOffKey.split('-')[1]);

                        for (let i = startHour; i <= endHour; i++) {
                            const cellId = `${startday}-${i.toString().padStart(2, '0')}`;
                            const cellElement = document.getElementById(cellId);
                            if (cellElement) {
                                cellElement.classList.remove('filled');
                                cellElement.classList.remove('N_filled');
                                cellElement.classList.add('newFelled');
                                cellElement.style.backgroundColor = '#4A8C6F';
                                previousCells.push(cellElement); 
                            }
                        }
                    }
                });
            })
            .catch(error => console.error("Error fetching presence time: ", error));
    };

    fetchData();

    date_from.addEventListener('change', fetchData);
    date_end.addEventListener('change', fetchData);

});