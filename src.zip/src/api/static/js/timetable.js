function fetching_data() {
    fetch(`/getData/${employeeNum}`)
    .then(response => response.json())
    .then(data => {
        const Timing = data.time || [];

        console.log(Timing);

        document.querySelectorAll('td').forEach(td => {
            td.classList.remove('filled');
            td.style.backgroundColor = '';
            const buttons = td.querySelectorAll('button');
            buttons.forEach(button => button.remove());
        });


        Timing.forEach(timeWork => {
            const day = timeWork.day;
            const start_hour = timeWork.time_in.split(':')[0];
            const hour = start_hour.length === 1 ? '0' + start_hour : start_hour;
            const cellId = `${day}-${hour}`;
            const cell = document.getElementById(cellId);

            if (cell) {
                cell.classList.add('filled');
                cell.style.backgroundColor = 'green';

                if (!cell.querySelector('.trash')) {
                    const trash = document.createElement('button');
                    trash.className = 'trash';
                    trash.addEventListener('click', () => handleDelete(day, start_hour));
                    cell.appendChild(trash);
                }

            } else {
                console.error(`Cell with ID ${cellId} not found`);
            }
        });
    })
    .catch(error => console.error("Error fetching Time work: ", error));
};

document.addEventListener('DOMContentLoaded', () => {
    document.querySelector('#form').addEventListener('submit', (event) => {
        event.preventDefault();

        const day = document.getElementById('day').value;
        const start_hour = document.getElementById('from').value;
        const end_hour = document.getElementById('to').value;

        const FromHour = parseInt(start_hour.split(':')[0]);
        const ToHour = parseInt(end_hour.split(':')[0]);

        const timetable = [];

        function getNextDay(currentDay) {
            const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
            const currentIndex = daysOfWeek.indexOf(currentDay);
            const nextIndex = (currentIndex + 1) % daysOfWeek.length;
            return daysOfWeek[nextIndex];
        }

        if (FromHour >= ToHour) {
            for (let i = FromHour; i < 24; i++) {
                const entry = {
                    day: day,
                    time_in: `${i < 10 ? '0' + i : i}:00`,
                    time_off: `${i+1 < 10 ? '0' + (i+1) : i+1}:00`
                };
                timetable.push(entry);
            }
            const nextDay = getNextDay(day);
            for (let i = 0; i < ToHour; i++) {
                const entry = {
                    day: nextDay,
                    time_in: `${i < 10 ? '0' + i : i}:00`,
                    time_off: `${i+1 < 10 ? '0' + (i+1) : i+1}:00`
                };
                timetable.push(entry);
            }
        } else {
            for (let i = FromHour; i < ToHour; i++) {
                const entry = {
                    day: day,
                    time_in: `${i < 10 ? '0' + i : i}:00`,
                    time_off: `${i+1 < 10 ? '0' + (i+1) : i+1}:00`
                };
                timetable.push(entry);
            }
        }

        console.log(timetable);

        fetch(`/InsertTime/${employeeNum}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(timetable)
        })
        .then(response => response.json())
        .then(data => {
            alert('Data inserted successfully!' + JSON.stringify(data));
            fetching_data();
            var card = document.getElementById("card");
		    card.style.display = "none";
        })
        .catch(error => {
            console.error('Error:', error);
        });
    });

    fetching_data();

});

function handleDelete(day, hour) {
    const HourForm = `${hour}:00`;

    fetch(`/delete/${employeeNum}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            day: day,
            start_hour: HourForm
        })
    })
    .then(response => response.json())
    .then(data => {
        fetching_data();
    })
    .catch(error => {
        console.error('Error:', error);
        alert("An error occurred: " + data.error);
    });
}
