document.getElementById('send').addEventListener("click", async (event) => {
    event.preventDefault();

    const reg_num = document.getElementById('reg-num').value;
    const email = document.getElementById('email').value;

    try {
        const response = await fetch('/sendPassword', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                reg_num: reg_num,
                email: email
            })
        });

        const data = await response.json();

        if (response.ok) {
            if (data.success) {
                alert('A verification code has been sent to your email!');
                document.querySelector('.overlay').style.display = 'block';
                document.querySelector('.card-ChangePassword').style.display = 'block';
            } else {
                alert('Error: ' + data.message);
            }
        } else {
            alert('HTTP error! Status: ' + response.status);
        }
    } catch (error) {
        console.error('There was an error!', error);
        alert('An error occurred. Please try again.');
    }
});

document.querySelector('.submit-btn').addEventListener("click", async (event) => {
    event.preventDefault();

    const code = document.getElementById('code').value;
    const newpassword = document.getElementById('New_password').value;
    const Confirm_Password = document.getElementById('Confirm_Password').value;

    if (newpassword != Confirm_Password) {
        VRF = document.querySelector('.VRF')
        overlay = document.querySelector('.overlay')
        VRF.style.display = 'block';
        overlay.style.display = 'block';
        document.getElementById('New_password').style.boxShadow = 'inset 0px 0px 0px 2px red';
        document.getElementById('Confirm_Password').style.boxShadow = 'inset 0px 0px 0px 2px red';
    }

    fetch('/resetPassword', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            verification_code: code,
            new_password: newpassword
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Password updated successfully!');
            window.location.href = '/sign-in';
        } 
        else {
            alert('Error: ' + data.message);
        }
    })
})